setwd("C:\\Users\\it24101011\\Desktop")
#Q1
data <- read.csv("Exercise.txt",header = TRUE)
#Q2
View(branch_data)
head(branch_data)
str(branch_data)

#Q3
boxplot(branch_data$Sales_X1, main ="Boxplot for slaes",ylab = "sales")
summary(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)

#Q4
find_outliers <- function(x){
  Q1 <- quantile(x,0.25)
  Q3 <- quantile(x,0.75)
  IQR_value <- IQR(x)
  lower_bound <- Q1 -1.5 * IQR_value
  upper_bound <- Q3 + 1.5 *IQR_value
  outliers <- x[x < lower_bound | x > upper_bound]
  return(outliers)
}

#Q5
outliers_advertising <- find_outliers(branch_data$Advertising_X2)
outliers_advertising