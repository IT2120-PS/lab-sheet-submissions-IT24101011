setwd("C:\\Users\\jinathi\\Desktop\\IT24101011\\Data.csv")
customers <- c(55, 62, 43, 46, 50)

# Expected probabilities (equal for all days)
expected_probs <- rep(1/5, 5)

# Chi-Square Goodness of Fit Test
chisq_test1 <- chisq.test(customers, p = expected_probs)

# Display results
chisq_test1


url <- "http://www.sthda.com/sthda/RDoc/data/housetasks.txt"
housetasks <- read.table(url, header = TRUE, row.names = 1)

# Display dataset
housetasks

# Perform Chi-Square Test of Independence
chisq_test2 <- chisq.test(housetasks)

# Display results
chisq_test2


# Exercise

snacks <- c(120, 95, 80, 100)

# Expected probabilities (equal choice)
expected_probs_snacks <- rep(1/4, 4)

# Chi-Square Goodness of Fit Test
chisq_test3 <- chisq.test(snacks, p = expected_probs_snacks)

# Display results
chisq_test3

