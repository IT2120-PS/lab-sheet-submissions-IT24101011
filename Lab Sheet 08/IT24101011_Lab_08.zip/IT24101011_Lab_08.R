getwd()
setwd("C:\\Users\\it24101011\\Desktop\\IT24101011\\Lab 08-20250926")
##import the data set
data <- read.table("Exercise - Laptopsweights.txt", header = TRUE)
fix(data)
attach(data)


##Question 01
popmn <- mean(Weight.kg.)
popmn
popsd <- sd(Weight.kg.)
popsd


##Question 02
samples <- c()
n <- c()

for (i in 1:25) {
  s <- sample(Weight.kg., 6, replace = TRUE)
  samples <- cbind(samples, s)
  n <- c(n, paste('s', i))
}
samples
n

colnames(samples) = n
samples

s.mean <- apply(samples, 2, mean)
s.mean

s.sd <- apply(samples, 2, sd)
s.sd


##Question 03
samplemean <- mean(s.mean)
samplemean
samplesd <- sd(s.mean)
samplesd

##Compairing the values
popmn
samplemean

popsd
samplesd

